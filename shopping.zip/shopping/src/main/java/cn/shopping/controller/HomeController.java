package cn.shopping.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/home")
public class HomeController {

    @RequestMapping(value = "/index.do")
    public String index() {
        return "index";
    }

    @RequestMapping(value = "/about.do")
    public String about() {
        return "about";
    }

    @RequestMapping(value = "/goodsList.do")
    public String goodsList() {
        return "goodsList";
    }

    @RequestMapping(value = "/goodsDetails.do")
    public String goodsDetails() {
        return "goodsDetails";
    }

}
