package cn.shopping.controller;


import cn.shopping.pojo.Users;
import cn.shopping.service.PersonalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping(value = "/personal")
public class PersonalController{

    @Autowired
    public PersonalService personalService;

    @RequestMapping(value = "/login.do")
    public String login(){
        return "personal/login";
    }

    @RequestMapping(value = "/checkLogin.do")
    public String checkLogin(HttpServletRequest request, HttpServletResponse response, Model model){
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Integer aLong = personalService.checkLogin(username, password);
        if(aLong!=null){

            Cookie cookie = new Cookie("username", username);    // (name,value);

            cookie.setMaxAge(3600 * 24);

            cookie.setPath("/");

            response.addCookie(cookie);
            model.addAttribute("username",cookie.getValue());
            return "personal/index";
        }else{
            return "personal/login";
        }

    }


    @RequestMapping(value = "/checkRegister.do")
    public String checkRegister(HttpServletRequest request, Users users){
        users.setUsername(request.getParameter("username"));
        users.setPassword(request.getParameter("password"));
        users.setAddress(request.getParameter("address"));
        users.setPhone(request.getParameter("phone"));
        users.setZipCode(request.getParameter("zipCode"));
        Integer users1 = personalService.checkRegister(users);
        if(users1!=null){
             return "personal/login";
        }else{
            return "personal/register";
        }

    }

    @RequestMapping(value = "/register.do")
    public String register(){
        return "personal/register";
    }

    @RequestMapping(value = "/index.do")
    public String index(){
        return "personal/index";
    }

    @RequestMapping(value = "/addGoods.do")
    public String addGoods(){
        return "personal/goods/addGoods";
    }

    @RequestMapping(value = "/selectGoods.do")
    public String selectGoods(){
        return "personal/goods/selectGoods";
    }

    @RequestMapping(value = "/selectOrders.do")
    public String selectOrders(){
        return "personal/orders/selectOrders";
    }

    @RequestMapping(value = "/modifyPassword.do")
    public String modifyPassword(){
        return "personal/system/modifyPassword";
    }

}
