package cn.shopping.controller;

import cn.shopping.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;

    @RequestMapping(value = "/index.do")
    public String index(){
        return "admin/index";
    }

    @RequestMapping(value = "/notice.do")
    public String notice(){
        return "admin/notice";
    }

    @RequestMapping(value = "/login.do")
    public String login(){
        return "admin/login";
    }

    @RequestMapping(value = "/checkLogin.do")
    public String checkLogin(HttpServletRequest request)
    {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if(username.equals("admin")&&password.equals("admin")){
            HttpSession session = request.getSession();
            session.setAttribute("username", username);   //将数据存储到session中
            return "admin/index";
        }else{
            return "admin/login";
        }

    }

    @RequestMapping(value = "/loginOut.do")
    public String loginOut(HttpServletRequest request)
    {
        request.getSession().invalidate();
        return "admin/login";
    }

    @RequestMapping(value = "/selectUsers.do")
    public String selectUsers(){
        return "admin/users/selectUsers";
    }


    @RequestMapping(value = "/selectGoods.do")
    public String selectGoods(){

        return "admin/goods/selectGoods";
    }

    @RequestMapping(value = "/selectOrders.do")
    public String selectOrders(){
        return "admin/orders/selectOrders";
    }

    @RequestMapping(value = "/addType.do")
    public String addType(){
        return "admin/types/addType";
    }

    @RequestMapping(value = "/checkAddType.do")
    public String checkAddType(HttpServletRequest request){

        return "admin/types/addType";
    }


    @RequestMapping(value = "/selectType.do")
    public String selectType(){
        return "admin/types/selectType";
    }



    @RequestMapping(value = "/selectOrder.do")
    public String selectOrder(){
        return "admin/types/selectOrder";
    }

    @RequestMapping(value = "/modifyPassword.do")
    public String modifyPassword(){
        return "admin/system/modifyPassword";
    }
}
