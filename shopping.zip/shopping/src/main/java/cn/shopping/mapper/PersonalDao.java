package cn.shopping.mapper;

import cn.shopping.pojo.Users;

public interface PersonalDao {
    Integer checkLogin(String username,String password);
    Integer checkRegister(Users users);

}
