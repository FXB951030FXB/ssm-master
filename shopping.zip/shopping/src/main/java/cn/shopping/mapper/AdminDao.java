package cn.shopping.mapper;

import org.springframework.stereotype.Repository;

@Repository
public interface AdminDao {

}
