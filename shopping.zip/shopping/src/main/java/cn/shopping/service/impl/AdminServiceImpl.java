package cn.shopping.service.impl;

import cn.shopping.service.AdminService;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService{




}
