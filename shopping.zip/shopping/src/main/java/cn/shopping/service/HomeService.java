package cn.shopping.service;

public interface HomeService {


}
