package cn.shopping.service;

import cn.shopping.pojo.Users;

public interface PersonalService {

    Integer checkLogin(String username,String password);
    Integer checkRegister(Users users);


}
