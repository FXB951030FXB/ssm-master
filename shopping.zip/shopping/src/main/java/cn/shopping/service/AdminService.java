package cn.shopping.service;

public interface AdminService {


}
