package cn.shopping.service.impl;

import cn.shopping.mapper.PersonalDao;
import cn.shopping.pojo.Users;
import cn.shopping.service.PersonalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class PersonalServiceImpl implements PersonalService {

    @Autowired
    public PersonalDao personalDao;

    public Integer checkLogin(String username, String password){
       return  personalDao.checkLogin(username,password);
    }
    public Integer checkRegister(Users users){
       return personalDao.checkRegister(users);
    }

}
