package cn.shopping.pojo;

public class Order {
    private int id;
    private int uid;
    private int gid;
    private int tid;

    public Order() {
    }

    public Order(int id, int uid, int gid, int tid) {
        this.id = id;
        this.uid = uid;
        this.gid = gid;
        this.tid = tid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getGid() {
        return gid;
    }

    public void setGid(int gid) {
        this.gid = gid;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", uid=" + uid +
                ", gid=" + gid +
                ", tid=" + tid +
                '}';
    }
}
