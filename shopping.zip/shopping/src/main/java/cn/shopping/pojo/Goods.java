package cn.shopping.pojo;

public class Goods {
    private int id;
    private String name;
    private String price;
    private int uid;
    private String image;
    private int tid;

    public Goods() {
    }

    public Goods(int id, String name, String price, int uid, String image, int tid) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.uid = uid;
        this.image = image;
        this.tid = tid;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    @Override
    public String toString() {
        return "Goods{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price='" + price + '\'' +
                ", uid=" + uid +
                ", image='" + image + '\'' +
                ", tid=" + tid +
                '}';
    }
}
