package cn.shopping.pojo;

public class Admin {
}
