package cn.shopping.filter;


import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        // 1.如果是和登录有关的资源，以及静态资源，直接放行
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String uri = request.getRequestURI();
        if(uri.contains("login") || uri.contains("Login") || uri.contains("/static/css/") || uri.contains("/static/js/")){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        // 2.如果登录了，放行
        Object username = request.getSession().getAttribute("username");
        if(username != null){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }
        // 3.如果没登录，跳转到登录页面

        request.getRequestDispatcher("/admin/login.jsp").forward(servletRequest,servletResponse);

    }

    @Override
    public void destroy() {

    }
}
